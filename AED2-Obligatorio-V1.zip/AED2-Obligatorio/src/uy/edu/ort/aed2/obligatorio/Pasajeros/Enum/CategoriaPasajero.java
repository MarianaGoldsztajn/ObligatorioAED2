package uy.edu.ort.aed2.obligatorio.Pasajeros.Enum;

public enum CategoriaPasajero {
    Platino,
    Frecuente,
    Estandar,
    Esporadico,
    Nuevo
}
